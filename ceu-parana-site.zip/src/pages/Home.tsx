import React from "react";
import { useLanguage } from "../contexts/LanguageContext";
import ImageCarousel from "../components/ImageCarousel";

const Home: React.FC = () => {
  const { t } = useLanguage();
  return (
    <div className="space-y-8">
      <div className="grid gap-6 md:grid-cols-2 items-center">
        <div className="space-y-4">
          <p className="text-sm uppercase tracking-wide text-sky-400">CEU Paraná</p>
          <h1 className="text-3xl md:text-4xl font-bold text-white">{t("heroTitle")}</h1>
          <p className="text-slate-200">{t("heroSubtitle")}</p>
          <div className="flex gap-4">
            <a
              href="/contato"
              className="bg-sky-500 hover:bg-sky-600 text-white px-4 py-2 rounded-md font-medium transition-colors"
            >
              Entre em contato
            </a>
            <a
              href="/sobre"
              className="border border-sky-500/50 hover:border-sky-400 text-white px-4 py-2 rounded-md font-medium transition-colors"
            >
              Conheça a CEU
            </a>
          </div>
        </div>
        <ImageCarousel />
      </div>
      <div className="grid md:grid-cols-3 gap-4">
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <h2 className="font-semibold text-lg mb-2">Moradia acessível</h2>
          <p className="text-slate-300 text-sm">Ambiente seguro e acolhedor para estudantes de todo o Paraná.</p>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <h2 className="font-semibold text-lg mb-2">Comunidade</h2>
          <p className="text-slate-300 text-sm">Convivência colaborativa, eventos e suporte.</p>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <h2 className="font-semibold text-lg mb-2">Processo seletivo</h2>
          <p className="text-slate-300 text-sm">Condições especiais para estudantes de baixa renda.</p>
        </div>
      </div>
    </div>
  );
};

export default Home;
