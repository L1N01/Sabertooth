import React from "react";
import { useLanguage } from "../contexts/LanguageContext";

const Contact: React.FC = () => {
  const { t } = useLanguage();
  return (
    <div className="max-w-xl space-y-4">
      <h1 className="text-2xl font-bold text-white">Contato</h1>
      <p className="text-slate-200">{t("contactText")}</p>
      <form className="space-y-4">
        <div>
          <label className="block text-sm text-slate-200">Nome</label>
          <input className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-slate-50" />
        </div>
        <div>
          <label className="block text-sm text-slate-200">E-mail</label>
          <input type="email" className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-slate-50" />
        </div>
        <div>
          <label className="block text-sm text-slate-200">Mensagem</label>
          <textarea rows={4} className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-slate-50" />
        </div>
        <button
          type="submit"
          className="bg-sky-500 hover:bg-sky-600 px-4 py-2 rounded-md text-white font-medium transition-colors"
        >
          Enviar
        </button>
      </form>
    </div>
  );
};

export default Contact;
