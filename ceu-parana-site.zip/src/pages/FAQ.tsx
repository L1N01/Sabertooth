import React from "react";
import { useLanguage } from "../contexts/LanguageContext";

const FAQ: React.FC = () => {
  const { t } = useLanguage();
  const faqs = [
    {
      q: "Como funciona o processo seletivo?",
      a: "Geralmente ocorre uma vez por ano e leva em conta situação socioeconômica e desempenho acadêmico."
    },
    {
      q: "A CEU oferece alimentação?",
      a: "Sim, há estrutura compartilhada e, em alguns períodos, apoio de alimentação."
    },
    {
      q: "Posso visitar a CEU antes de me inscrever?",
      a: "Sim, entre em contato pelos canais oficiais para agendar."
    }
  ];

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold text-white">FAQ</h1>
      <p className="text-slate-200">{t("faqText")}</p>
      <div className="space-y-3">
        {faqs.map((item) => (
          <details key={item.q} className="bg-slate-900 border border-slate-800 rounded-md p-3">
            <summary className="cursor-pointer font-medium text-slate-50">{item.q}</summary>
            <p className="mt-2 text-slate-200 text-sm">{item.a}</p>
          </details>
        ))}
      </div>
    </div>
  );
};

export default FAQ;
