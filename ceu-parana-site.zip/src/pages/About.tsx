import React from "react";
import { useLanguage } from "../contexts/LanguageContext";

const About: React.FC = () => {
  const { t } = useLanguage();
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold text-white">Sobre a CEU Paraná</h1>
      <p className="text-slate-200">{t("aboutText")}</p>
      <p className="text-slate-300">
        A Casa do Estudante Universitário do Paraná é uma entidade tradicional que acolhe estudantes de diversas
        regiões, oferecendo estrutura, alimentação e suporte para que possam se dedicar aos estudos.
      </p>
    </div>
  );
};

export default About;
