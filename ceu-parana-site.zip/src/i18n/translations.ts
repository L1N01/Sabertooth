export type SupportedLang = "pt" | "en";

export const translations: Record<SupportedLang, Record<string, string>> = {
  pt: {
    siteTitle: "CEU Paraná",
    home: "Início",
    about: "Sobre",
    contact: "Contato",
    faq: "FAQ",
    heroTitle: "Casa do Estudante Universitário do Paraná",
    heroSubtitle: "Moradia estudantil acolhedora e acessível há mais de 50 anos.",
    aboutText: "A CEU Paraná oferece estrutura, segurança e comunidade para universitários.",
    contactText: "Preencha o formulário e entraremos em contato.",
    faqText: "Principais dúvidas sobre o processo seletivo e a moradia.",
    footerText: "© {year} CEU Paraná - Casa do Estudante Universitário. Todos os direitos reservados."
  },
  en: {
    siteTitle: "CEU Paraná",
    home: "Home",
    about: "About",
    contact: "Contact",
    faq: "FAQ",
    heroTitle: "Student House of Paraná",
    heroSubtitle: "Affordable, welcoming student housing for over 50 years.",
    aboutText: "CEU Paraná offers structure, safety and community for university students.",
    contactText: "Fill in the form and we'll get in touch.",
    faqText: "Main questions about the selection process and housing.",
    footerText: "© {year} CEU Paraná - Student House. All rights reserved."
  }
};
