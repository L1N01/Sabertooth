export const siteConfig = {
  name: "CEU Paraná",
  description: "Site institucional da Casa do Estudante Universitário do Paraná",
  links: {
    instagram: "#",
  },
};
