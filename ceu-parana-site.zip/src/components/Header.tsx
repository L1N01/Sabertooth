import React from "react";
import { Link, useLocation } from "react-router-dom";
import LanguageSelector from "./LanguageSelector";
import { useLanguage } from "../contexts/LanguageContext";

const Header: React.FC = () => {
  const location = useLocation();
  const { t } = useLanguage();

  const navItems = [
    { to: "/", label: t("home") },
    { to: "/sobre", label: t("about") },
    { to: "/contato", label: t("contact") },
    { to: "/faq", label: t("faq") },
  ];

  return (
    <header className="bg-slate-900/70 border-b border-slate-800 backdrop-blur sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between gap-4">
        <Link to="/" className="text-xl font-bold tracking-tight text-sky-400">
          {t("siteTitle")}
        </Link>
        <nav className="flex items-center gap-4">
          {navItems.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className={`text-sm md:text-base transition-colors ${
                location.pathname === item.to
                  ? "text-sky-400"
                  : "text-slate-200 hover:text-sky-200"
              }`}
            >
              {item.label}
            </Link>
          ))}
          <LanguageSelector />
        </nav>
      </div>
    </header>
  );
};

export default Header;
