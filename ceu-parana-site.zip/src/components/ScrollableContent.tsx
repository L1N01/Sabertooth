import React from "react";

const ScrollableContent: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <div className="max-h-80 overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-slate-700 scrollbar-track-slate-900">
      {children}
    </div>
  );
};

export default ScrollableContent;
