import React from "react";

const images = [
  "https://images.unsplash.com/photo-1460518451285-97b6aa326961?w=1200&q=60",
  "https://images.unsplash.com/photo-1476922027627-aa7293e3aaa8?w=1200&q=60",
  "https://images.unsplash.com/photo-1519451241324-20b4ea2c4220?w=1200&q=60"
];

const ImageCarousel: React.FC = () => {
  const [index, setIndex] = React.useState(0);

  React.useEffect(() => {
    const id = setInterval(() => {
      setIndex((prev) => (prev + 1) % images.length);
    }, 5000);
    return () => clearInterval(id);
  }, []);

  return (
    <div className="relative w-full h-64 overflow-hidden rounded-xl border border-slate-800">
      {images.map((src, i) => (
        <img
          key={src}
          src={src}
          alt="CEU Paraná"
          className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-700 ${i === index ? "opacity-100" : "opacity-0"}`}
        />
      ))}
    </div>
  );
};

export default ImageCarousel;
