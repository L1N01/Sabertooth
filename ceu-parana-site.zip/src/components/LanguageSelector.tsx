import React from "react";
import { useLanguage } from "../contexts/LanguageContext";

const LanguageSelector: React.FC = () => {
  const { lang, setLang } = useLanguage();
  return (
    <select
      value={lang}
      onChange={(e) => setLang(e.target.value as "pt" | "en")}
      className="bg-slate-800 text-slate-100 border border-slate-700 rounded-md px-2 py-1 text-sm"
    >
      <option value="pt">PT</option>
      <option value="en">EN</option>
    </select>
  );
};

export default LanguageSelector;
